import './App.css';
import DashBoard from './components/DashBoard';
import Header from './components/Layout/Header';
import { BrowserRouter as Router , Route } from 'react-router-dom';
import addproject from './components/Project/addproject';

function App() {
  return (
   <div>
    <DashBoard/>
   </div>
  );
}

export default App;
