import React, { Component } from 'react'

export default class addproject extends Component {
  render() {
    return (
      <div>
        <h1>add project form.</h1>
      </div>
    );
  }
}
